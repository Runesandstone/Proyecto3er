package com.inmtzjc.practica5_baulinteligente

// --- IMPORTS OBLIGATORIOS PARA QUE TODO COMPILE A LA PRIMERA ---
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: FileAdapter
    private val fileList = mutableListOf<FileModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 🔥 PRUEBA DE FUEGO: Forzamos la creación de un archivo real en la memoria interna
        // para que la app tenga algo real que listar y no se vea vacía.
        try {
            val archivoPrueba = "Examen_Aprobado.pdf"
            val contenido = "Evidencia de la Practica 5 - Baul Inteligente."
            openFileOutput(archivoPrueba, MODE_PRIVATE).use {
                it.write(contenido.toByteArray())
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        setupRecyclerView()
        checkPermissionsAndLoadFiles()
    }

    private fun setupRecyclerView() {
        val rv = findViewById<RecyclerView>(R.id.recyclerView)
        adapter = FileAdapter(fileList)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        // --- TEMA 4.6: Drag and Drop ---
        val callback = object : ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0) {
            override fun onMove(rv: RecyclerView, vh: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
                adapter.onItemMove(vh.adapterPosition, target.adapterPosition)
                return true
            }
            override fun onSwiped(vh: RecyclerView.ViewHolder, direction: Int) {}
        }
        ItemTouchHelper(callback).attachToRecyclerView(rv)
    }

    // --- TEMA 4.8: Permissions ---
    private fun checkPermissionsAndLoadFiles() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED) {
            // Pedir permiso al usuario
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 101)
        } else {
            loadFilesFromStorage()
        }
    }

    // Captura la respuesta del permiso por si el usuario lo acepta en el momento
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 101 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            loadFilesFromStorage()
        } else {
            // Si lo deniega, de todos modos cargamos para mostrar los datos de prueba
            loadFilesFromStorage()
            Toast.makeText(this, "Permiso denegado. Mostrando archivos locales.", Toast.LENGTH_SHORT).show()
        }
    }

    // --- TEMA 4.9: Files and Persistence ---
    private fun loadFilesFromStorage() {
        val directory = filesDir
        val files = directory.listFiles()

        // Limpiamos la lista para evitar que se dupliquen al recargar
        fileList.clear()

        // Agregamos los archivos reales encontrados en el almacenamiento interno de la app
        files?.forEach {
            fileList.add(FileModel(it.hashCode(), it.name, it.absolutePath))
        }

        // Si por alguna razón la carpeta está vacía, dejamos estos mockups de respaldo
        if (fileList.isEmpty()) {
            fileList.add(FileModel(1, "Documento_Tarea.pdf", "/fake/path/1"))
            fileList.add(FileModel(2, "Presentacion_Final.pdf", "/fake/path/2"))
            fileList.add(FileModel(3, "Apuntes_Clase.pdf", "/fake/path/3"))
        }

        adapter.notifyDataSetChanged()
    }

    // --- TEMA 4.7: Intents ---
    // NOTA: Se quitó el 'private' para que FileAdapter.kt pueda invocar esta función al hacer clic
    fun shareFile(fileModel: FileModel) {
        val actualFile = File(fileModel.path)

        // Si el archivo es falso (de los de prueba), creamos uno rápido para que no falle el Intent
        if (!actualFile.exists()) {
            try {
                openFileOutput(fileModel.name, MODE_PRIVATE).use {
                    it.write("Contenido de respaldo".toByteArray())
                }
            } catch (e: Exception) { e.printStackTrace() }
        }

        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.provider", actualFile)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "Compartir archivo de mi Baúl"))
        } catch (e: Exception) {
            Toast.makeText(this, "Error al compartir: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}

// ========================================================================
// CLASES DE SOPORTE INTEGRADAS
// ========================================================================

// Únicamente conservamos el FileModel. El FileAdapter ya NO va aquí
// porque ya vive de forma independiente en su propio archivo FileAdapter.kt
data class FileModel(
    val id: Int,
    val name: String,
    val path: String
)