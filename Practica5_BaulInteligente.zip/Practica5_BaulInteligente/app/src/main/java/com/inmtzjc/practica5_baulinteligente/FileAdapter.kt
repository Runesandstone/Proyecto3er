package com.inmtzjc.practica5_baulinteligente

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FileAdapter(private var fileList: MutableList<FileModel>) :
    RecyclerView.Adapter<FileAdapter.FileViewHolder>() {

    class FileViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.tvFileName)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FileViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_file, parent, false)
        return FileViewHolder(view)
    }

    override fun onBindViewHolder(holder: FileViewHolder, position: Int) {
        holder.name.text = fileList[position].name
    }

    override fun getItemCount() = fileList.size

    // Método para mover items (Tema 4.6)
    fun onItemMove(fromPosition: Int, toPosition: Int) {
        val movedItem = fileList.removeAt(fromPosition)
        fileList.add(toPosition, movedItem)
        notifyItemMoved(fromPosition, toPosition)
    }
}
